﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 基础测绘计算
{
    public partial class qfjh : Form
    {
        public qfjh()
        {
            InitializeComponent();
        }

        private void qfjh_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x1 = Convert.ToDouble(textBox1.Text);
            double y1 = Convert.ToDouble(textBox2.Text);
            double x2 = Convert.ToDouble(textBox3.Text);
            double y2 = Convert.ToDouble(textBox4.Text);
            double a = Convert.ToDouble(textBox5.Text);
            double b = Convert.ToDouble(textBox6.Text);
            double m = 0;
            double n = 0;
            jisuan.jdqfjh(x1, y1, x2, y2, a, b, out m, out n);
            textBox7.Text = m.ToString();
            textBox8.Text = n.ToString();

        }
    }
}
