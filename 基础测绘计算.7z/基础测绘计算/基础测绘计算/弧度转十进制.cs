﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 基础测绘计算
{
    public partial class hdzsjz1 : Form
    {
        public hdzsjz1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text;
            double a = jisuan.huduzsjz(str);
            textBox2.Text = a.ToString();
        }
    }
}
