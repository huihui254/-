﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 基础测绘计算
{
    public partial class dwzb : Form
    {
        public dwzb()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void 根据起点坐标_距离_方位角计算点位坐标_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBox1.Text);
            double y = Convert.ToDouble(textBox2.Text);
            double d = Convert.ToDouble(textBox4.Text);
            double a = jisuan.dmszhudu(textBox5.Text);
            double m = 0;
            double n = 0;
            jisuan.zuobiao(x, y, d, a, out m, out n);
            textBox6.Text = m.ToString();
            textBox7.Text = n.ToString();
        }
    }
}
