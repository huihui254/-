﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 基础测绘计算
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            dwzb a = new dwzb();
            a.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dmszsjz1 a = new dmszsjz1();
            a.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            sjzzdms1 a = new sjzzdms1();
            a.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            hdzsjz1 a = new hdzsjz1();
            a.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sjzzhd1 a = new sjzzhd1();
            a.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            hdzdms1 a = new hdzdms1();
            a.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dmszhd1 a = new dmszhd1();
            a.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            zbfwjjs a = new zbfwjjs();
            a.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            jljh a = new jljh();
            a.Show();
           
        }

        private void button10_Click(object sender, EventArgs e)
        {
            qfjh a = new qfjh();
            a.Show();
        }

        
    }
}
