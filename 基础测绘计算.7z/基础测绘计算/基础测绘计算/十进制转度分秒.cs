﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 基础测绘计算
{
    public partial class sjzzdms1 : Form
    {
        public sjzzdms1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttom1_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text;
            string a = jisuan.sjzzdms(str);
            textBox2.Text = a;
        }
    }
}
