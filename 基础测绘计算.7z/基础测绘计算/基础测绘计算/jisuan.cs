﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 基础测绘计算
{
    public struct point
    {
        public double x, y;
        public point (double x,double y)
        {
            this.x = x; this.y = y;
        }
    }
    public static class jisuan
    {
        public static double ldjl(double x1, double y1, double x2, double y2)
        {
            double dx = x2 - x1;
            double dy = y2 - y1;
            return Math.Sqrt(dx * dx + dy * dy);
        }
        public static double dmszsjz(string x)
        {
            int iDrgee;
            double dSec, dMin, dDms;
            double a = Convert.ToDouble(x);
            iDrgee = (int)a;
            dMin = (int)((a - iDrgee) * 100);
            dSec = (a - iDrgee - dMin / 100) * 10000;
            dDms = iDrgee + dMin / 60 + dSec / 3600;
            return dDms;
        }
        public static string sjzzdms(string x)
        {
            int iDrgee;
            double dSec, dMin;
            double a = Convert.ToDouble(x);
            iDrgee = (int)a;
            dMin = (int)((a - iDrgee) * 60);
            dSec = (int)((a - iDrgee - dMin / 60) * 3600);
            return iDrgee + "度" + dMin + "分" + dSec + "秒";
        }
        public static double huduzsjz(string x)
        {
            double a = Convert.ToDouble(x);
            double b = a * 180 / Math.PI;
            return b;
        }
        public static double sjzzhudu(string x)
        {
            double a = Convert.ToDouble(x);
            double b = a / 180 * Math.PI;
            return b;
        }
        public static string huduzdms(string x)
        {
            int iDrgee;
            double dSec, dMin;
            double b = Convert.ToDouble(x);
            double a = b * 180 / Math.PI;
            iDrgee = (int)a;
            dMin = (int)((a - iDrgee) * 60);
            dSec = (int)((a - iDrgee - dMin / 60) * 3600);
            return iDrgee + "度" + dMin + "分" + dSec + "秒";
        }
        public static double dmszhudu(string x)
        {
            int iDrgee;
            double dSec, dMin, dDms;
            double a = Convert.ToDouble(x);
            iDrgee = (int)a;
            dMin = (int)((a - iDrgee) * 100);
            dSec = (a - iDrgee - dMin / 100) * 10000;
            dDms = iDrgee + dMin / 60 + dSec / 3600;
            double b = dDms / 180 * Math.PI;
            return b;
        }
        public static double za(double x1, double y1, double x2, double y2)//计算两点连线的坐标方位角
        {
            double dx = x2 - x1;
            double dy = y2 - y1;
            double azimuth;
            if (dx == 0)
            {
                if (dy > 0)
                {
                    azimuth = Math.PI / 2;
                    return azimuth;
                }
                else
                {
                    azimuth = Math.PI * 3 / 2;
                    return azimuth;
                }
            }
            else
            {
                double x = dy / dx;
                double R = Math.Atan(x);
                if (dx < 0)
                {
                    azimuth = R + Math.PI;
                    return azimuth;
                }
                else
                {
                    if (dy <= 0)
                    {
                        azimuth = R + Math.PI * 2;
                        return azimuth;
                    }
                    else
                    {
                        azimuth = R;
                        return azimuth;
                    }
                }
            }

        }
        public static void zuobiao(double x, double y, double d, double a, out double m, out double n)
        {
            m = x + d * Math.Cos(a);
            n = y + d * Math.Sin(a);
        }
        public static void cbjh(double x1, double y1, double x2, double y2, double d1, double d2, out double m, out double n)
        {
            double dx = x2 - x1;
            double dy = y2 - y1;
            double ab = za(x1, y1, x2, y2);
            double d3 = ldjl(x1, y1, x2, y2);
            double bap = Math.Acos((d3 * d3 + d1 * d1 - d2 * d2) / (2 * d3 * d1));
            double ap = ab - bap;
            m = x1 + d1 * Math.Cos(ap);
            n = y1 + d1 * Math.Sin(ap);
            //double abp = Math.Acos((d3 * d3 + d2 * d2 - d1 * d1) / (2 * d3 * d2));
            //double bp = ap + abp;
            //m = x2 + d2 * Math.Cos(bp);
            //n = y2 + d2 * Math.Sin(bp);
        }
        public static void jdqfjh(double x1, double y1, double x2, double y2, double a, double b, out double m, out double n)
        {
            a = dmszhudu(a.ToString());
            b = dmszhudu(b.ToString());
            m = (x1 / Math.Tan(b) + x2 / Math.Tan(a) + y2 - y1) / (1 / Math.Tan(a) + 1 / Math.Tan(b));
            n = (y1 / Math.Tan(b) + y2 / Math.Tan(a) + x2 - x1) / (1 / Math.Tan(a) + 1 / Math.Tan(b));
        }
    }
}

