﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 基础测绘计算
{
    public partial class zbfwjjs : Form
    {
        public zbfwjjs()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double jg, jg1;
            point p1 = new point();
            point p2 = new point();
            p1.x = Convert.ToDouble(textBox1.Text);
            p1.y = Convert.ToDouble(textBox2.Text);
            p2.x = Convert.ToDouble(textBox3.Text);
            p2.y = Convert.ToDouble(textBox4.Text);
            double dx = p2.x - p1.x;
            double dy = p2.y - p1.y;//计算dx,dy
            if (dx == 0 && dy == 0)
            {
                MessageBox.Show("输入有误，程序退出");
                this.Close();
            }
            else
            {
                jg = jisuan.za(p1.x,p1.y,p2.x,p2.y);
                textBox5.Text = jisuan.huduzdms(jg.ToString());
                if (jg < 180)//计算反坐标方位角根据是否小于180判断
                {
                    jg1 = jg + Math.PI;
                }
                else
                {
                    jg1 = jg - Math.PI;
                }
                textBox6.Text= jisuan.huduzdms(jg1.ToString());
                textBox7.Text= Math.Sqrt(dx * dx + dy * dy).ToString();
            }
        }
    }
}

